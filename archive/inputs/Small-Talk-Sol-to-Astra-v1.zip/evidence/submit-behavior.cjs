const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const handlers={},timers=[],windowHandlers={};
const button={textContent:'Add to bag · ₹699',disabled:false};
const form={id:'DesiProductForm',dataset:{},querySelector:()=>button};
const document={getElementById:()=>null,addEventListener:(name,fn)=>handlers[name]=fn,querySelectorAll:()=>[form],contains:()=>true};
vm.runInNewContext(fs.readFileSync('current-theme/assets/desi.js','utf8'),{document,window:{addEventListener:(name,fn)=>windowHandlers[name]=fn},HTMLElement:class{},customElements:{get:()=>true},setTimeout:fn=>timers.push(fn)});
function submit(){let prevented=false;handlers.submit({target:form,preventDefault:()=>prevented=true});return prevented;}
assert.equal(submit(),false);assert.equal(button.textContent,'Adding…');assert.equal(submit(),true);
timers.shift()();assert.equal(button.textContent,'Add to bag · ₹699');assert.equal(form.dataset.sending,'false');
submit();windowHandlers.pageshow();assert.equal(button.textContent,'Add to bag · ₹699');assert.equal(form.dataset.sending,'false');
submit();timers.shift()();assert.equal(button.textContent,'Adding…');timers.shift()();assert.equal(button.textContent,'Add to bag · ₹699');
button.disabled=true;assert.equal(submit(),true);assert.equal(button.textContent,'Add to bag · ₹699');
console.log('PASS: submit guard, duplicate guard, exact label timeout recovery, pageshow recovery, unavailable guard. Synthetic DOM; no transaction.');
