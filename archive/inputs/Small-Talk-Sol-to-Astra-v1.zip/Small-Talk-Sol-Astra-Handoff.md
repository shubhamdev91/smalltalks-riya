# Small Talk — Sol → Astra handoff

Version SOL-HANDOFF-2026-10-09-v1. Prepared 9 October UTC / 8 October Los Angeles. This is a saved handoff for the user to forward; no message has been sent.

## Installed state

Store: 0nev20-vn.myshopify.com. Exact target: Copy of Small Talk — Desi Ink / Artwork correction, 186573160661, UNPUBLISHED. Installed SOL-02, theme updatedAt 2026-10-09T04:44:01Z. Live 186547241173 remains MAIN with unchanged updatedAt 2026-10-07T03:49:38Z.

Two JavaScript files are installed and exact readback matches. assets/desi.js MD5 e70854ea94d3e90ffced69e345b5b55d; assets/desi-enhancements.js MD5 2284dd3090f2997ddf7e2e34be76d380. Native section installed by SOL-01: sections/di-product.liquid MD5 ac1342d9b6b60fd16aff6a5865001c77.

SOL-02 removes the competing full-page variant reload and retains one in-place variant handler. Price, button label, availability and quantity rules update together. Submit guards preserve exact original wording, block duplicate/unavailable submit and use a token so an old timeout cannot reset a later submission. SOL-01 main-nail blur releases its temporary keyboard hold. No choreography, timing, geometry or artwork was changed.

Validation: official Theme Check helper passed changed files with bundled Shopify schemas after remote docs refresh failed. JavaScript syntax and focused synthetic variant/submit tests passed. Synthetic tests are not a real transaction or native multi-variant acceptance.

## Motion source transfer and integration constraints

The accompanying current-source package is an exact relevant subset of installed Shopify source, with a SHA-256 manifest, rendered seven-campaign JSON and theme settings. It is a source handoff, not an installable theme or an Astra motion release.

Include assets/desi.js, assets/desi-motion.js, assets/desi-enhancements.js, the three current CSS layers, sections/di-hero.liquid, sections/di-chapter.liquid, snippets/di-nail.liquid, snippets/di-nail-sequence.liquid, snippets/di-link.liquid, layout/theme.liquid and relevant settings/index JSON. The installed refinements/chapter come from SOL-03 prewrite backups; staged creative changes must not masquerade as installed source.

The included runtime-dom.json captures the actual HTML data-campaigns output after SOL-02. Keep the campaign schema keys: key, name, headline, note, index, background, foreground, ctaBackground, ctaForeground, url, nails, preview, character. Values are supplied by Liquid campaign blocks. Use real product references through di-link; do not hard-code prototype product links or prices.

Theme asset settings: di_fingers = four-tone atlas; di_nails = main atlas; di_nail_accents = third-row atlas; di_hand_base = overlayable preview-hand base; di_hands = older per-campaign hand atlas; di_characters = character atlas. Preserve their exact source URLs and mappings in settings and runtime data. Nail columns: On Me 0, Brainwave 1, Diet Cherry 2, Green Flag 3, Shaadi Shift 4, Wild Card 5, Pinky Promise 6. The five-nail row order is in di-nail-sequence and ROWS in desi.js. Same-set switching retains product identity.

Current controller ownership is mixed: desi.js owns the hero plus review-link mapping, menu Escape and native product submission. Replace/reconcile the hero controller only when integrating Astra's release. Preserve unrelated handlers and desi-enhancements.js. One hero controller and one state clock must run; two competing custom-element definitions are not integration.

Finite clock, hold/focus release, offscreen/hidden/pagehide pause reasons, reduced motion, manual controls and cleanup are acceptance contracts. Preserve settings and section load/unload behavior. Do not turn a skin tone into a sellable variant. Normal vertical scrolling remains available.

Receipt: Astra Small-Talk-Motion-v0.1.zip, libfile_d2381c9d7fec8191b5b2a4a0dcfe245c. Read-only development/integration review; NOT production released, NOT installed. Astra checklist v2 flags rejected five-visible-nail hand and finger-edge fringe. Existing artwork is an inherited baseline, not new creative approval.

## Installed evidence and reproducible findings

All browser evidence here uses a cloud desktop viewport 1363 × 936. Mobile/touch, actual phones and native checkout remain unverified.

| Item | Evidence / reproduction | Status |
|---|---|---|
| Gallery | Brainwave preview → View the five-nail design; settled track scrollLeft 525, clientWidth 513, scrollWidth 1038; only second thumb aria-current=true. Packaging return and Enter are also recorded in checklist. | Desktop observed pass |
| Journal | Prior saved sequence 1→2→3→4→3 and correct disabled ends. Current SOL-02 regression advances after smooth-scroll settlement. Rapid clicks during settling can coalesce; immediate counters are not settled evidence. | Desktop pass; rapid behavior note |
| Shop filters/search | Everyday selects four matching preview cards; Brainwave search leaves one; All sets preserves the query; no-result search exposes empty state. | Desktop observed pass |
| Empty bag | Correct empty state, Explore the sets and Help links rendered; no checkout action for an empty bag. | Desktop observed pass |
| Help | Search “sizing” leaves Fit & application; “zzzz-no-result” leaves no topics and exposes the empty state. | Desktop observed pass |
| Menu | Prior Enter/Escape check returns focus to summary; current hero Space then Tab focus navigation produces no captured storefront runtime error. | Desktop observed |
| Hero pause | See screenshots/hero-paused.jpg. After Pause animation, main nail bed is bare and an incoming nail is frozen beside it. Source hides the main nail during flights. Ask Astra whether a paused flight should settle or retain an attached nail; Sol has not re-choreographed it. | Creative defect/review |
| Hero preview | Current hand remains a five-nail view; Astra has already rejected it for the final four-visible-nail composition. | Astra dependency |
| Commerce | Saved API facts: seven sets DRAFT, ₹0, inventory 0, onlineStoreUrl null. Browser Brainwave is correctly Coming soon. No product/price/inventory changes made. | Real commerce blocked |
| Console | Captured error logs originate from browser extension metadata messaging; no storefront JavaScript error observed in this sample. This does not prove every path error-free. | Sample only |

Screenshots are installed old visual state, not the uninstalled palette/prop patch. The first Brainwave screenshot was captured while scrolling; use gallery-settled.jpg for gallery evidence.

## Technical SEO and performance findings

- Preview product/story routes are query-view review templates, not final crawlable product/article routes. Brainwave preview renders its title, meta description, noindex,follow and home canonical. Preserve preview protection. Homepage itself need not inherit preview-template noindex.
- Review mode rewrites links client-side using DesiReviewRoutes. Native launch routes and shared product/article/page fields must be reconciled before launch; do not claim the review shell is a finished indexed catalogue.
- Native di-product renders Shopify product structured_data; review-product template has no equivalent sellable product JSON-LD. Current draft facts prevent launch validation. No synthetic price, stock, review or rating schema was added.
- Existing robots.txt and sitemap.xml snapshot from 8 October returned 200. Robots disallows preview_theme_id and transactional routes; sitemap index lists Shopify-generated child sitemaps. These are previously captured HTTP observations, not new crawl/CWV tests. Redirect query previously returned none. No robots/sitemap/redirect shared-record changes made.
- Technical findings go to Astra; final search intent and metadata wording remain Astra-owned. Native metadata installation is a shared-record change outside current authority.
- No current Lighthouse score, Core Web Vitals or mobile animation-cost measurement is claimed. Existing WOFF2 improvements are historical source/checkpoint evidence. Loading new notebook remains blocked. Its staged derivative is 323432 bytes versus 2312314-byte PNG (~86% smaller), same 1536 × 1024 canvas and exact alpha, visually inspected at q94. That is asset encoding evidence, not page-speed evidence.

## COLOR-01 / ART-01 ready review patch, not installed

Received Astra handoff libfile_1ba68bc1970481918136fd815fc48629 and asset package libfile_56ddffac6378819190463cee4d9aed29. The separate SOL-03 patch contains only:

1. Scoped neutral-page palette appended to assets/desi-refinements.css: blue actions/functional controls, plum neutral headings/editorial actions, body ink, secondary text, ivory/lilac surfaces, identifiable form borders and offset focus rings. Campaign variables and wordmarks stay unchanged.
2. Brainwave-only notebook fallback in sections/di-chapter.liquid, retaining existing merchant art override. Empty decorative alt; explicit 1536 × 1024 dimensions; lazy loading; contain; 90% mobile width / maximum 520px desktop; content may grow and story link remains outside copy/prop bounds.
3. assets/desi-brainwave-notebook-v1.webp, visually inspected derivative of exact Astra source. No redraw or generated substitution.

Theme Check passed. Exact prewrite backups and human-readable diffs are included in the review patch. Remote creative files remain unchanged and the new asset is absent.

Automatic approval review rejected SOL-03 before execution: it considered image/CSS/Liquid an expansion beyond the authorized JavaScript repair without sufficiently clear user authorization. No retry or indirect write. User approval is pending. Installed desktop/mobile palette and cobalt-fringe checks, Astra visual approval and performance evidence remain open; there are no installed screenshots of SOL-03.

## Supporting stories — DRAFT v1 for Astra editorial review

Destination: Journal campaign stories/carousels, not PDP replacement copy. These are fictional Small Talk brand stories, never testimonials. Approved slogans stay exact. The five beats can become four slides by merging beats 1–2 after editorial approval; retain a readable HTML story transcript. Keep proposed wording separate until approval.

### On Me — “Bill idhar.”

1. The bill lands face down between four half-empty glasses. Everyone reaches for a phone. She reaches for the little leather folder first.
2. Her first freelance payment arrived that afternoon. She hasn’t told them yet; she wanted one evening where the news didn’t have to become a big announcement.
3. “Split kar lete hain,” someone says. Usually, she would agree before anyone could object. Tonight she opens the folder and leaves it in front of her.
4. A friend notices the gold on her nails, then the look on her face. “Something happened?” She smiles. “Haan. Something good.”
5. They can buy the next coffee. This one, she’s choosing. Her hand rests on the bill while the table finally stops negotiating. “Bill idhar.”

Journal link label proposal: Explore On Me.

### Brainwave — “Haan, mera idea hai.”

1. The notebook is open between the coffee cups. Someone points at the crescent-shaped bag in the margin. “Where did you find this?”
2. She nearly names the references first. The curves she studied. The strap she kept changing. The three versions that looked better in her head.
3. Her friend turns the notebook a little closer. “No, this one. Who designed this?” For a moment, she hears how ready she was to disappear from her own answer.
4. She puts one blue-tipped finger beside the corrected curve. There’s a smudge where she rubbed out the first line. She leaves it visible.
5. The sketch isn’t finished. Neither is everything she wants to make. But this much is hers, and she can say it without an asterisk. “Haan, mera idea hai.”

Journal link label proposal: Explore Brainwave.

### Diet Cherry — “Haan, wohi wali.”

1. They’re meant to be trying somewhere new. There’s a shared list, a saved reel and one friend who has already checked the menu.
2. Then someone asks, “Last time wali jagah?” The table goes quiet for half a second. Everyone remembers the booth and the song they sang badly.
3. She was going to suggest a different order, too. A slightly more interesting version of herself, apparently. Now she’s laughing at the effort.
4. Her cherry-red nails tap the rim of the familiar can. Someone spots them and says, “You knew we’d end up here, didn’t you?”
5. She didn’t. But there’s relief in wanting the same thing without having to defend it. She slides the menu back and gives her order. “Haan, wohi wali.”

Journal link label proposal: Explore Diet Cherry.

### Green Flag — “Tum aa jao. Main dekh lungi.”

1. The phone rings while she’s clearing the table. Her friend starts with “It’s fine,” which is how she knows it probably isn’t.
2. The evening’s plans have fallen apart. There’s a bag already packed, nowhere appealing to go and the exhausting question of whether anyone really wants company.
3. She listens before offering a solution. Then she moves the laundry off the spare chair and remembers there’s enough food for two.
4. One green-tipped finger turns the old phone cord around itself. Her other hand sets out another glass. There’s no grand rescue to arrange.
5. Just a chair, something warm and permission to arrive without being entertaining. Before her friend can apologise for the third time: “Tum aa jao. Main dekh lungi.”

Journal link label proposal: Explore Green Flag.

### Shaadi Shift — “Dulhan tu. Duty meri.”

1. Five minutes before the photographs, the bride whispers, “My earring.” One is in place. The other has vanished somewhere between the chair and her dupatta.
2. Everyone has a suggestion. She has the tiny pouch her friend handed her that morning: pins, tissues and things that apparently become essential at exactly the wrong moment.
3. The earring is caught in the lining. She finds it without calling the whole room over. Her friend’s shoulders drop before either of them says anything.
4. Her nails catch the light as she places it in the bride’s palm, then straightens the edge of the dupatta. A small job, done without making it another event.
5. “What would I do without you?” The photographer is waiting; there’ll be time for that later. She checks the pouch once more and grins. “Dulhan tu. Duty meri.”

Journal link label proposal: Explore Shaadi Shift.

### Wild Card — “Achha. Tum pehle.”

1. She’s been pretending to study her cards for a full minute. Really, she’s listening to the person opposite her explain a rule everyone already knows.
2. Her friend notices the smile and kicks her lightly under the table. She keeps her cards facing herself. There are some things the room doesn’t need to read yet.
3. “Your turn,” he says. She has a good hand. She also wants to see whether he’ll keep talking if she gives him another moment.
4. Her dark, patterned nails settle along the edge of the cards. She tilts them closer, hiding both the hand and the little change of plan.
5. Winning would be satisfying. So would finding out where this conversation goes. She looks up, makes room for one more move and says, “Achha. Tum pehle.”

Journal link label proposal: Explore Wild Card.

### Pinky Promise — “Haath do. Main hoon.”

1. At the doorway, her friend stops. Inside, everyone seems to know where to stand and what to say. “You go. I’ll come in a minute.”
2. They’ve had this conversation before, in different places. Sometimes she waited. Sometimes she tried too hard to make the room sound less intimidating than it felt.
3. Tonight she doesn’t give a speech. She steps back beside her friend and asks which corner looks least crowded. They pick the same one.
4. Her lilac nails show as she opens her palm. Her friend takes it, loosely at first. They can let go whenever they want.
5. No promise that the night will be brilliant. Just that the first few steps don’t have to happen alone. She nudges the door with her shoulder. “Haath do. Main hoon.”

Journal link label proposal: Explore Pinky Promise.

## Supporting UI copy proposals — review only

Existing approved production wording stays unchanged until Astra approves these specific additions.

| Location | Proposed addition | Purpose |
|---|---|---|
| Journal intro | Little moments, told properly. A bill, a phone call, a familiar hand. | Clarify story content without selling constantly |
| Each fictional story | An original Small Talk brand story. | Preserve existing fiction label |
| Journal empty search | No stories found. Try another word, or see all stories. | Clear recovery action |
| Talks rules addition | Leave out real names and identifying details. Share the moment, not someone else’s private information. | Useful moderation guidance; does not promise anonymity |
| Help link | Ask us about fit and kit details. | Route factual unknowns to support without inventing answers |

Our Story, core headlines and campaign lines are already approved; no replacement draft is needed simply to create more copy.

## Factual FAQ register — owner/supplier inputs required

Do not publish the “missing” column as public placeholder text. Until a claim is verified, keep it out of purchase copy and structured data.

| Question | Current evidence | Missing verification / intended answer |
|---|---|---|
| Can I order now? | Seven-set API snapshot DRAFT/₹0/0; review buttons Coming soon | Owner price, stock and activation decision; recheck before launch |
| What comes in the box? | Product kit_contents fields absent | Count, sizes, adhesive, prep tools and exact pack contents per SKU |
| Which size should I choose? | No verified dimensions/fit table | Supplier measurement method, width table, sizing options and between-size guidance |
| How do I apply/remove them? | Application/removal fields absent | Instructions for the actual included adhesive; safe removal procedure, not generic assumptions |
| How long do they last? | No wear-time evidence | Tested wear conditions and range; avoid guarantees |
| Can I reuse them or get them wet? | Care/material fields absent | Material, water/contact limits and reuse conditions verified by supplier |
| Where and when do you deliver? | Shipping policy missing; Help Delivery routes to contact | Destinations, fees, dispatch cutoff and actual carrier expectations |
| What if it arrives damaged? Can I return it? | Refund policy missing; Help Returns routes to contact | Eligibility, reporting window, evidence, return/exchange process and applicable exclusions |
| How do I contact you? | Native Help form and correctly labelled fields observed | Verify actual receiving mailbox and response expectations; do not send test message without authorization |
| Is the skin shade a product option? | Theme control changes visual atlas only | Approved plain answer: skin shade previews the look; it does not change the set selected |

## Astra review requests

Please approve/revise the seven Journal drafts and specific UI additions; retain locked slogans. Release a production-identified motion package only after visual review, with exact files, responsive rules and accepted artwork. Review the paused bare-nail state and preview-hand composition. Return final metadata specifications separately from content. After SOL-03 receives user authorization and is installed, review full-context palette/notebook screenshots; current screenshot evidence is not that approval.
